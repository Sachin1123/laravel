<<<<<<< HEAD
@extends('layouts.app')

@section('content')

+<div class="card">
<div class="card-body">
    <h4 class="card-title"> Event </h4>
    <form action="{{route('event')}}"  method="POST">
   
        @csrf
        <label for="name"> Description</label>
        <br>
        <textarea  name="name" id='description'cols="50" row="3"></textarea>
       </br>
       <br>
       <label for="start_time"> Start Date</label>
       <input type='date'  name='start_date'>
       </br>
       <br>
       <label for="end_time">End Date</label>
       <input type='date'  name='end_date'>
       </br>
       <input type='submit'  value='Submit'>
    </form>
</div>
</div>
@endsection

=======
<!DOCTYPE html>
<html>
<head>
    <title>Laravel Fullcalender</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
  
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.24.0/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.js"></script>
  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" />
</head>
<body>
  
<div class="container">
    <h1>Laravel FullCalender </h1>
    <div id='calendar'></div>
</div>
   
<script>
$(document).ready(function () {
 
   
var SITEURL = "{{ url('/') }}";
  
$.ajaxSetup({
    
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
    
    }
});



var calendar = $('#calendar').fullCalendar({
    header: {
      left: 'prev,next today',
      center: 'description',
      right: 'month,agendaWeek,agendaDay,listWeek',
    },
  
                    editable: true,                   
                    events:  "/fullcalender",
                    displayEventTime: true,
                  
                    eventRender: function (event, element, view) {
                        if (event.allDay === 'true') {
                                event.allDay = true;
                        } else {
                                event.allDay = false;
                        }
                        element.find('.fc-title').append("<br/>" + event.description);
                        // console.log(event);
                        
                    },
                    selectable: true,
                    selectHelper: true,
                    select: function (start, end, allDay) {
                        var description = prompt('Event Title:');
                      
                        if (description) {
                           
                            var start = $.fullCalendar.formatDate(start, "Y-MM-DD");
                            var end = $.fullCalendar.formatDate(end, "Y-MM-DD");
                           
                            $.ajax({
                                url: SITEURL + "/fullcalenderAjax",
                                data: {
                                    description: description,
                                    start_date: start,
                                    end_date: end,
                                    type: 'add'
                                   
                                },
                                
                                type: "POST",
                                success: function (data) {
                                displayMessage("Event Created Successfully");
                            
                                    calendar.fullCalendar('renderEvent',
                                        {
                                            id: data.id,
                                            description: description,
                                            start: start,
                                            end: end,
                                            allDay: allDay
                                        },true);
  
                                    calendar.fullCalendar('unselect');
                                }
                            });
                            
                        }
                    },
                    eventDrop: function (event, delta) {
                        var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD");
                        var end= $.fullCalendar.formatDate(event.end, "Y-MM-DD");
  
                        $.ajax({
                            url: SITEURL + '/fullcalenderAjax',
                            data: {
                                description: event.description,
                                start: start,
                                end: end,
                                id: event.id,
                                type: 'update'
                            },
                           
                            type: "POST",
                            success: function (response) {
                                displayMessage("Event Updated Successfully");
                            }
                        });
                    },
                    eventClick: function (event) {
                        var deleteMsg = confirm("Do you really want to delete?");
                        if (deleteMsg) {
                            $.ajax({
                                type: "POST",
                                url: SITEURL + '/fullcalenderAjax',
                                data: {
                                        id: event.id,
                                        type: 'delete'
                                },
                                success: function (response) {
                                    calendar.fullCalendar('removeEvents', event.id);
                                    displayMessage("Event Deleted Successfully");
                                }
                            });
                        }
                    }
 
                });
 
});
 
function displayMessage(message) {
    toastr.success(message, 'Events');
    
} 
 
</script>
  
>>>>>>> public
